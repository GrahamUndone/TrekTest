﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using System.Threading.Tasks;

using Newtonsoft;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Dynamic;

namespace BikeTest.Controllers
{
    [RoutePrefix("api/bikes")]
    public class BikesController : ApiController
    {
        public async Task<IEnumerable<BikeModel>> GetBikes()
        {
            using (var client = new HttpClient())
            {
                var response = await client.GetAsync("https://trekhiringassignments.blob.core.windows.net/interview/bikes.json");

                var json = await response.Content.ReadAsStringAsync();

                var model = JsonConvert.DeserializeObject<List<Bikes>>(json);

                IEnumerable<BikeModel> results = model
                    .GroupBy(b => b.bikes)
                    .Select(b => new BikeModel
                    {
                        BikeName = b.Key,
                        BikeCount = b.Key.Count()
                    })
                    .OrderByDescending(b => b.BikeCount)
                    .Take(20)
                    .ToList();

                return results;
            }
        }
    }

    public class Bikes
    {
        public IList<string> bikes { get; set; }
    }

    public class BikeModel
    {

        public IList<string> BikeName { get; set; }

        public int BikeCount { get; set; }
    }

}
